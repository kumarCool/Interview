﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using AngularJS1.Models;

using System.Web.Mvc;
using System.Linq;
using System.Collections.Generic;


namespace AngularJS1.Controllers
{
    public class DataController : Controller
    {
        //
        // GET: /Data/
        //For fetch Last Contact
        public JsonResult GetLastContact()
        {
            // Students c = null;
            // c = getData();

            EmployeeEntities1 db = new EmployeeEntities1();
            Employee objEmp = null;//new Employee();
            int EmpId = 1;
            objEmp = db.Employees.Find(EmpId);
            return new JsonResult { Data = objEmp, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //Employee employee = db.Employees.Find(id);

            //Contact c = null;
            ////here MyDatabaseEntities our DBContext
            //using (MyDatabaseEntities dc = new MyDatabaseEntities())
            //{
            //    c = dc.Contacts.OrderByDescending(a => a.ContactID).Take(1).FirstOrDefault();
            //}
            //return new JsonResult { Data = c, JsonRequestBehavior = JsonRequestBehavior.AllowGet };


            //return new JsonResult { Data = c, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            // {"ID":1,"Name":"Harry","Gender":"Male","Fees":"2500","StandardID":9}

        }

        private SqlConnection Conn;
        private bool a;

        private void CreateConnection()
        {
            string ConnStr =
            ConfigurationManager.ConnectionStrings["RDConnectionString"].ConnectionString;
            Conn = new SqlConnection(ConnStr);
        }

        public Students getData()
        {
            CreateConnection();
            Students obj = new Students();
            string SqlString = "SELECT * FROM Students WHERE ID = 1;";
            SqlDataAdapter sda = new SqlDataAdapter(SqlString, Conn);
            DataSet dt = new DataSet();
            try
            {

                Conn.Open();
                sda.Fill(dt);
                foreach (DataRow dr in dt.Tables[0].Rows)
                {
                    obj.ID = Convert.ToInt16(dr["ID"]);
                    obj.Name = Convert.ToString(dr["Name"]);
                    obj.Gender = Convert.ToString(dr["Gender"]);
                    obj.Fees = Convert.ToString(dr["Fees"]);
                    obj.StandardID = Convert.ToInt16(dr["StandardID"]);
                }

            }
            catch (SqlException se)
            {
                //DBErLog.DbServLog(se, se.ToString());
            }
            finally
            {
                Conn.Close();
            }
            return obj;
        }

        public JsonResult UserLogin(LoginData d)
        {
            using (EmployeeEntities1 dc = new EmployeeEntities1())
            {
                var user = dc.Users.Where(a => a.Username.Equals(d.Username) && a.Password.Equals(d.Password)).FirstOrDefault();
                return new JsonResult { Data = user, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            }
        }


        public JsonResult GetEmployeeList()
        {
            List<Employee> Employee = new List<Employee>();
            using (EmployeeEntities1 dc = new EmployeeEntities1())
            {
                Employee = dc.Employees.OrderBy(a => a.FirstName).ToList();
            }

            return new JsonResult { Data = Employee, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
        }

        // Fetch Country
        public JsonResult GetCountries()
        {
            List<Country> allCountry = new List<Country>();
            using (EmployeeEntities1 dc = new EmployeeEntities1())
            {
                allCountry = dc.Countries.OrderBy(a => a.CountryName).ToList();
            }
            return new JsonResult { Data = allCountry, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
        }
  
              // Fetch State by Country ID
         public JsonResult GetStates(int countryID)
         {
             List<State> allState = new List<State>();
             using (EmployeeEntities1 dc = new EmployeeEntities1())
             {
                 //allState = dc.States.Where(a => a.CountryID.Equals(countryID)).OrderBy(a => a.StateName).ToList();
                 allState = dc.States.Where(a => a.CountryID == countryID).OrderBy(a => a.StateName).ToList();
             }
             return new JsonResult { Data = allState, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
         }

         public ActionResult Part3view()//Fetch & show data
         {
             return View();

         }


         //[HttpPost]
         //public ActionResult InsertData(Contact e1)//Insert the data
         //{

         //    return View();
         //}

         public string AddEmployee(Employee Emp)
         {
             if (Emp != null)
             {
                 //using (SampleDBEntities dataContext = new SampleDBEntities())
                 //{
                 //    dataContext.Employees.Add(Emp);
                 //    dataContext.SaveChanges();
                 //    return "Employee Updated";
                 //}
                 return "Employee Updated";
             }
             else
             {
                 return "Invalid Employee";
             }
         }
    }
}