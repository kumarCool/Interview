﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AngularJS1.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Part2() // Fetch & Show Database Data
        {
            return View();
        }

        public ActionResult Part3() // Login from Database
        {
            return View();
        }

        public ActionResult Part4() // Retrive & Display Tabuler Data
        {
            return View();
        }
        public ActionResult Part5() // Implement Cascade dropdownlist
        {
            return View();
        }

        public ActionResult Part6() // Insert the data with form data
        {
            return View();
        }

    }
}
