﻿   angular.module('MyApp') // extending from previously created angular module in the First Part
  .controller('Part3Controller', function ($scope, LoginService) {
      alert('Part-1');
      debugger;
      $scope.IsLogedIn = false;
      $scope.Message = '';
      $scope.Submitted = false;
      $scope.IsFormValid = false;

      $scope.LoginData = {
          Username: '',
          Password: ''
      };

      //Check is Form Valid or Not // Here f1 is our form Name
      $scope.$watch('f1.$valid', function (newVal) {
          $scope.IsFormValid = newVal;
          alert('Part-4');
      });

      $scope.Login = function () {
          $scope.Submitted = true;
          if ($scope.IsFormValid) {
              LoginService.GetUser($scope.LoginData).then(function (d) {
                  if (d.data.Username != null) {
                      $scope.IsLogedIn = true;
                      $scope.Message = "Successfully login done. Welcome " + d.data.FullName;
                      alert('Part-5');

                  }
                  else {
                      alert('Invalid Credential!');
                  }
              });
          }
      };

  })
   .factory('LoginService', function ($http) {
       alert('Part-2');
       debugger;
       var fac = {};
       alert('Part-3');
       fac.GetUser = function (d) {
           return $http({
               url: '/Data/UserLogin',
               method: 'POST',
               data: JSON.stringify(d),
               headers: { 'content-type': 'application/json' }
           });
       };
       return fac;
   });
