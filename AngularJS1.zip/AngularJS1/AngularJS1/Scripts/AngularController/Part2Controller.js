﻿//here I am separating each angular controller to separate file for make it manageable  

angular.module('MyApp') //extending from previously created angular module in the previous part
.controller('Part2Controller', function ($scope, ContactService) { //inject ContactService
    $scope.Employee = null;
    debugger;
    alert('part-3');
    //ContactService.GetLastContact().then(function (d) {
    ContactService.GetLastContact().then(function (d) {
        $scope.Employee = d.data; // Success
        debugger;
        alert('part-4');
    }, function () {
        alert('Failed'); // Failed
    });
})
.factory('ContactService', function ($http) { // here I have created a factory which is a populer way to create and configure services
    alert('Part-1');
    debugger;
    var fac = {};
    fac.GetLastContact = function () {
        debugger;
        return $http.get('/Data/GetLastContact');
        
    }
    return fac;
});
