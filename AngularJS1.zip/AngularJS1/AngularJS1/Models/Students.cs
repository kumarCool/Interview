﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AngularJS1.Models
{
    public class Students
    {
        public int ID { get; set; }
        public string  Name { get; set; }
        public string Gender { get; set; }
        public string Fees { get; set; }
        public int StandardID { get; set; }

    }
}